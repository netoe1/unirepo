
library ieee;
use ieee.std_logic_1164.all;

entity PC_Sub is
    PORT (

    );
END PC_Sub;

architecture BEHAVIOR of PC_Sub is

   type type_state is ();
   
   signal state, next_state: type_state;

begin

    process ()
    begin

    end process;

    process ()
    begin
    end process;
	 
    process ()
    begin
	
    end process;       
	 
end behavior;
